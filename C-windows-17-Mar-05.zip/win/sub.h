/* Test problem specific variable declarations */

# ifndef _SUB_H
# define _SUB_H

# include "global.h"

# ifdef f5
long double **A;
long double *B;
# endif

# ifdef f12
long double **A;
long double **B;
long double *alpha;
# endif

# endif
